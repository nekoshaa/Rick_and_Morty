import React from 'react'
import { Card, Button } from 'react-bootstrap'
import { Link } from 'react-router-dom'


const ShopItem = ({ src, title = "Default Title", videoId, publishedAt, description, thumbnail }) => {
  return (


    <Card style={{ width: '16rem' }}>
      <Card.Img variant="top" src={src} />
      <Card.Body>
        <Card.Title>{videoId}</Card.Title>
        <Card.Title>{title}</Card.Title>
        <Card.Title>{publishedAt}</Card.Title>
        <Card.Title>{description}</Card.Title>
        <Card.Title>{thumbnail}</Card.Title>
        <Button variant="dark" onClick={() => { URL(videoId) }}>Открыть</Button>
        <  Link to={{ pathname: "/content", state: { src, title, videoId, publishedAt, description, thumbnail } }}
        > <Button variant="dark">Ссылка</Button></Link>
      </Card.Body>
    </Card>
  )
}

function URL(videoId) {
  window.open(`https://www.youtube.com/watch?v=${videoId}`, '_blank').focus();
}
export default ShopItem
