import React, { useState, useEffect } from 'react'
import axios from 'axios'
import ShopItem from '../ShopItem/ShopItem'


const ShopItemsList = () => {

  const [video, setPhotosList] = useState([])
  const [isLoading, setIsLoading] = useState(false)

  const fetchData = () => {
    setIsLoading(true)
    axios.get('https://www.testjsonapi.com/youtube-videos/')
      .then(function (response) {
        setPhotosList(response.data)
        setIsLoading(false)
      })
      .catch(function (error) {
        console.log(error);
        setIsLoading(false)
      })
  }

  useEffect(() => {
    fetchData()
  }, [])

  return (
    <>
      {isLoading
        ?
        <h1>Loading...</h1>
        :
        <>
          <div className="wrappedFlex">
            {video.map((videos) => {
              return <ShopItem title={videos.title} published={videos.publishedAt} description={videos.description} src={videos.thumbnail} videoId={videos.videoId} />
            })}
          </div>
        </>
      }
      <Content />
    </>
  )

}

export default ShopItemsList
